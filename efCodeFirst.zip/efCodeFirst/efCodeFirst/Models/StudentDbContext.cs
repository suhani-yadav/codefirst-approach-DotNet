﻿using Microsoft.EntityFrameworkCore;

namespace efCodeFirst.Models
{
    public class StudentDbContext : DbContext
    {
        // Constructor for DbContext
        public StudentDbContext(DbContextOptions options) : base(options)
        {
        }

        // DbSet to represent the Students table
        public DbSet<Student> Students { get; set; }
    }
}

