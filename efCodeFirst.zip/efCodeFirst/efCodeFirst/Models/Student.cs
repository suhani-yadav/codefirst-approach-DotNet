﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace efCodeFirst.Models
{
    public class Student
    {
        // Primary Key
        [Key]
        public int Id { get; set; }

        // Specify column name and type
        [Column("StudentName", TypeName = "varchar(234)")]
        [Required]
        public string Name { get; set; }

        [Required]
        [Column("StudentGender", TypeName = "varchar(120)")]
        public string Gender { get; set; }

        [Required]
        [Column("StudentAge", TypeName = "int")]
        public int? Age { get; set; }
    }
}
