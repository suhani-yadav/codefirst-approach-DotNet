using efCodeFirst.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace efCodeFirst.Controllers
{
    public class HomeController : Controller
    {
        private readonly StudentDbContext studentDb;
        //create constructor class 
        public HomeController(StudentDbContext studentDb )
        {
            //here we  are initializing 
            this.studentDb = studentDb;
        }

        public IActionResult Index()
        {
            // custom changes done here 
            var stdata=studentDb.Students.ToList();
            return View(stdata);
        }

      
        
        //insertion of data done here 
        //when we CREATE data or press submit button  in  table display in browser  then handle http request
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task <IActionResult> Create(Student std)
        {
            if(ModelState.IsValid)
            {
                //whatever data inserted /added stored in studnetDb  
               await studentDb.Students.AddAsync(std);
                await studentDb.SaveChangesAsync();
                TempData["insert_success"] = "inserted";

                return RedirectToAction("Index","Home");
            }
            //if request failed in anycase then data show by it
            return View(std);
        }

        public async Task<IActionResult> Details(int? id)
        {
            
            if(id==null||studentDb.Students==null)
            {
                //either id or student data null then return not found data
                return NotFound();
            }
           
            //whatever data inserted /added stored in studentDb  
            var stdData= await studentDb.Students.FirstOrDefaultAsync(x=>x.Id==id);
            if(stdData==null)
            {
                return NotFound();
            }
                return View(stdData);
            
            
        }
        //edit
        public async Task <IActionResult> Edit(int? id)
        {
            if (id == null || studentDb.Students == null)
            {
                //either id or student data null then return not found data
                return NotFound();
            }

            var stdData = await studentDb.Students.FindAsync(id);
            if (stdData == null)
            {
                return NotFound();
            }
            return View(stdData);
        }

        // HTTPREQUEST run for --> press on save button then it run
        [HttpPost]
        [ValidateAntiForgeryToken]
        public  async Task <IActionResult> Edit(int? id,Student std)
        {

            if(id!=std.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                //whatever data inserted /added/updated stored in std  
                 studentDb.Students.Update(std);
                await studentDb.SaveChangesAsync();
                TempData["update_success"] = "updated";

                return RedirectToAction("Index", "Home");
            }
            return View(std);
        }

        //Get method work in it
        public async Task < IActionResult> Delete(int? id )
        {
            if (id == null || studentDb.Students == null)
            {
                //either id or student data null then return not found data
                return NotFound();
            }

            var stdData = await studentDb.Students.FirstOrDefaultAsync(x => x.Id == id);
            if (stdData == null)
            {
                return NotFound();
            }
            return View(stdData);
        }

        //DELETE HTTP REQUEST RUN
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int? id)
        {
            var stdData = await studentDb.Students.FindAsync(id);
            if (stdData!= null)
            {
                studentDb.Students.Remove(stdData);
            }

            //changes saved here 
            await studentDb.SaveChangesAsync();
            TempData["delete_success"] = "deleted";

            //redirect to our home page
            return RedirectToAction("Index", "Home");

        }




        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
